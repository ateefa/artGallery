from django.apps import AppConfig


class StaffAccountConfig(AppConfig):
    name = 'staff_account'
